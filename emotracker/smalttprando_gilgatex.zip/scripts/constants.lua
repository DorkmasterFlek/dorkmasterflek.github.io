------------------------------------------------------------------
-- Extra constants defined for this pack.  These may be overridden for specific variants.
------------------------------------------------------------------
BIZHAWK_MODE = false
