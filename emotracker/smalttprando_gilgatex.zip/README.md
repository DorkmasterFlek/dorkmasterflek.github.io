# SMZ3 tracker pack
This is a map tracker for the Super Metroid + A Link to the Past Combo randomizer. To use with [EmoTracker](https://emotracker.net).

Ninban has decided to no longer work on the tracker, so I (Dorkmaster Flek) am taking over this project.  I can be found in the Emotracker discord as well as the ALttP + SM Randomizer discord for any questions, issues or bugs!

## Thanks
Gilgatex - The original author of this pack.  Without him, none of this would be possible so huge thanks!

Ninban - Took over managing this pack after Gilgatex until now.  Many thanks!
