# Super Metroid DASH Map Tracker Pack
This is a map & item tracker for the [Super Metroid DASH randomizer](https://dashrando.github.io) for use with [EmoTracker](https://emotracker.net).  It has full item and map tracking support, as well as autotracking on supported platforms.

## Thanks
[SauceRelic](https://github.com/SauceRelic) - Created the map/item tracker pack for the old Tewtal SM item randomizer, which was the basis for the DASH randomizer.  That pack was in turn the basis for this new pack specifically for the DASH rando, so huge thanks!
